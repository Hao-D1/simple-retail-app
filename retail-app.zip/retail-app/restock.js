const sqlite3 = require('sqlite3').verbose();
const cron = require('node-cron');

// Connect to the SQLite3 database
const db = new sqlite3.Database('./store.db');

// Schedule a daily job at midnight
cron.schedule('0 0 * * *', () => {
    console.log('Running daily restock job...');
    db.run('UPDATE items SET stock = 20', [], (err) => {
        if (err) {
            console.error('Error updating stock:', err.message);
        } else {
            console.log('All items restocked to 20.');
        }
    });
});
