const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const db = new sqlite3.Database('./store.db');

const fs = require('fs');

function logEvent(action, user = {}, item = {}) {
    const timestamp = new Date().toISOString();
    const logEntry = `[${timestamp}] ACTION: ${action}` +
        (user.name ? ` | USER: ${user.name} <${user.email}>` : '') +
        (item.name ? ` | ITEM: ${item.name} (ID: ${item.id})` : '') +
        '\n';

    fs.appendFileSync(path.join(__dirname, 'activity.log'), logEntry);
}

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'retail-secret', resave: false, saveUninitialized: true }));
app.use('/static', express.static(path.join(__dirname, 'static')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.get('/', (req, res) => {
    if (!req.session.name || !req.session.email) {
        return res.render('login');
    }

    db.all('SELECT * FROM items', [], (err, items) => {
        res.render('index', {
            name: req.session.name,
            email: req.session.email,
            items
        });
    });
});

app.post('/login', (req, res) => {
    req.session.name = req.body.name;
    req.session.email = req.body.email;
    res.redirect('/');
});

app.post('/add-to-cart/:id', (req, res) => {
    if (!req.session.cart) req.session.cart = [];
    const itemId = parseInt(req.params.id);
    db.get('SELECT * FROM items WHERE id = ?', [itemId], (err, item) => {
        if (item) {
            req.session.cart.push(item);
            logEvent('Add to Cart', req.session, item);
        }
        res.redirect('/');
    });
});

app.get('/cart', (req, res) => {
    res.render('cart', {
        name: req.session.name,
        email: req.session.email,
        cart: req.session.cart || []
    });
});

app.post('/purchase', (req, res) => {
    const cart = req.session.cart || [];
    cart.forEach(item => {
        db.run('UPDATE items SET stock = stock - 1 WHERE id = ? AND stock > 0', [item.id]);
        logEvent('Purchase Item', req.session, item);
    });
    req.session.cart = [];
    res.render('purchase', {
        name: req.session.name,
        email: req.session.email
    });
});

app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.send('Error logging out.');
        }
        res.redirect('/');
    });
});

app.get('/admin', (req, res) => {
    db.all('SELECT * FROM items', [], (err, items) => {
        logEvent('Admin Viewed Inventory');
        res.render('admin', { items });
    });
});

app.post('/admin/restock-all', (req, res) => {
    db.run('UPDATE items SET stock = 20', [], () => {
        res.redirect('/admin');
    });
});

app.post('/admin/restock/:id', (req, res) => {
    const itemId = req.params.id;
    const amount = parseInt(req.body.amount);
    db.get('SELECT * FROM items WHERE id = ?', [itemId], (err, item) => {
        if (item) {
            db.run('UPDATE items SET stock = stock + ? WHERE id = ?', [amount, itemId], () => {
                logEvent('Admin Restocked Item', {}, item);
                res.redirect('/admin');
            });
        }
    });
});

app.listen(3000, '0.0.0.0', () => console.log('Server running on http://localhost:3000'));
