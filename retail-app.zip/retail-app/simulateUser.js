const axios = require('axios');
const qs = require('qs');

const BASE_URL = 'http://localhost:3000';
const user = { name: 'SimUser', email: 'simuser@example.com' };
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

(async () => {
  const client = axios.create({ withCredentials: true });

  try {
    // Login
    await client.post(`${BASE_URL}/login`, qs.stringify(user));
    console.log(`Logged in as ${user.name}`);

    // Get homepage and extract item IDs
    const homepage = await client.get(BASE_URL);
    const itemIds = [...homepage.data.matchAll(/\\/add-to-cart\\/(\\d+)/g)].map(m => m[1]);

    if (itemIds.length === 0) {
      console.log('No items found.');
      return;
    }

    // Randomly add items to cart
    const count = Math.floor(Math.random() * 5) + 1;
    for (let i = 0; i < count; i++) {
      const itemId = itemIds[Math.floor(Math.random() * itemIds.length)];
      await client.post(`${BASE_URL}/add-to-cart/${itemId}`);
      console.log(`Added item ${itemId} to cart`);
      await delay(Math.random() * 3000 + 1000); // 1–4 sec delay
    }

    // Purchase
    await client.post(`${BASE_URL}/purchase`);
    console.log('Purchase completed');
  } catch (err) {
    console.error('Simulation failed:', err.message);
  }
})();
